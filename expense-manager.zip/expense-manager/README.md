# Expense Manager (Android, offline)

React Native (Expo) app. All data, including your account, lives in an on-device SQLite database. No internet is needed.

## Features
- Sign up / log in (password is salted and hashed; stays logged in until you log out). Each user's data is separate.
- **Expenses** (independent from loans): Fuel–Bike, Fuel–Car, Maintenance–Bike, Maintenance–Car, Food, Groceries, Shopping, Utility, Medicine. Paid by Cash or Mobile Account. Description + image (camera/gallery). Monthly totals, cash/mobile split, per-category totals, category filter.
- **Loans** (independent from expenses): add people; each profile has four entry types
  - I gave loan (they owe me more)
  - I took loan (I owe them more)
  - They repaid me / I repaid them
  Balance = (given − repaid to me) − (borrowed − repaid by me). Shows "You'll get" / "You owe" per person and overall. Description + image on each entry.
- Tap an item to edit, long-press to delete.

## Get the APK (pick one)

### Option A – GitHub Actions (free, no Expo account)
1. Create a new GitHub repo and push this folder to it (branch `main`).
2. Open the repo's **Actions** tab → "Build Android APK" runs automatically (or press *Run workflow*).
3. When it finishes (~10 min), open the run and download the **expense-manager-apk** artifact. Unzip it and install the `.apk` on your phone (allow "install unknown apps").

### Option B – EAS cloud build (free Expo account)
```
npm install
npx eas-cli login
npx eas-cli build -p android --profile apk
```
Download the APK from the link it prints.

### Option C – Locally (needs Android Studio / SDK + JDK 17)
```
npm install
npx expo prebuild --platform android
cd android && ./gradlew assembleRelease
```
APK: `android/app/build/outputs/apk/release/app-release.apk`

## Try quickly without building
`npx expo start`, then open in the Expo Go app on your phone.

## Notes
- Currency label is "Rs"; change `CURRENCY` in `src/constants.js`.
- Data is only on the phone. Uninstalling or clearing app data deletes it.

import React, { useState } from 'react';
import {
  ActivityIndicator,
  Image,
  KeyboardAvoidingView,
  Modal,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors } from './theme';
import { monthLabel } from './utils';

export function Screen({ title, onBack, right, children }) {
  const insets = useSafeAreaInsets();
  return (
    <View style={[s.screen, { paddingTop: insets.top }]}>
      <View style={s.header}>
        {onBack ? (
          <TouchableOpacity onPress={onBack} style={s.backBtn} hitSlop={10}>
            <Text style={s.backTxt}>‹</Text>
          </TouchableOpacity>
        ) : (
          <View style={{ width: 8 }} />
        )}
        <Text style={s.title} numberOfLines={1}>
          {title}
        </Text>
        <View style={s.right}>{right}</View>
      </View>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior="padding">
        <View style={{ flex: 1, paddingBottom: insets.bottom }}>{children}</View>
      </KeyboardAvoidingView>
    </View>
  );
}

export function Card({ children, style }) {
  return <View style={[s.card, style]}>{children}</View>;
}

export function Button({ title, onPress, kind = 'primary', disabled, loading, small, style }) {
  const bg = kind === 'primary' ? colors.primary : kind === 'danger' ? colors.danger : colors.card;
  const fg = kind === 'secondary' ? colors.primary : '#fff';
  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled || loading}
      activeOpacity={0.8}
      style={[
        s.btn,
        small && s.btnSmall,
        { backgroundColor: bg, opacity: disabled ? 0.5 : 1 },
        kind === 'secondary' && { borderWidth: 1, borderColor: colors.primary },
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={fg} />
      ) : (
        <Text style={[s.btnTxt, small && { fontSize: 14 }, { color: fg }]}>{title}</Text>
      )}
    </TouchableOpacity>
  );
}

export function Field({ label, style, ...props }) {
  return (
    <View style={{ marginBottom: 14 }}>
      <Text style={s.label}>{label}</Text>
      <TextInput
        placeholderTextColor={colors.muted}
        {...props}
        style={[s.input, props.multiline && { minHeight: 84, textAlignVertical: 'top' }, style]}
      />
    </View>
  );
}

export function Chip({ label, icon, selected, onPress }) {
  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.8}
      style={[s.chip, selected && { backgroundColor: colors.primary, borderColor: colors.primary }]}
    >
      <Text style={[s.chipTxt, selected && { color: '#fff' }]}>
        {icon ? icon + ' ' : ''}
        {label}
      </Text>
    </TouchableOpacity>
  );
}

export function Fab({ label, onPress }) {
  return (
    <TouchableOpacity onPress={onPress} activeOpacity={0.85} style={s.fab}>
      <Text style={s.fabTxt}>{label}</Text>
    </TouchableOpacity>
  );
}

export function Empty({ text }) {
  return (
    <View style={{ alignItems: 'center', paddingVertical: 40 }}>
      <Text style={{ color: colors.muted, fontSize: 15, textAlign: 'center' }}>{text}</Text>
    </View>
  );
}

export function MonthSwitcher({ month, onChange }) {
  return (
    <View style={s.monthRow}>
      <TouchableOpacity onPress={() => onChange(-1)} hitSlop={12} style={s.monthBtn}>
        <Text style={s.monthArrow}>‹</Text>
      </TouchableOpacity>
      <Text style={s.monthTxt}>{monthLabel(month)}</Text>
      <TouchableOpacity onPress={() => onChange(1)} hitSlop={12} style={s.monthBtn}>
        <Text style={s.monthArrow}>›</Text>
      </TouchableOpacity>
    </View>
  );
}

export function ImageViewer({ uri, onClose }) {
  return (
    <Modal visible={!!uri} transparent animationType="fade" onRequestClose={onClose}>
      <Pressable style={s.viewer} onPress={onClose}>
        {uri ? <Image source={{ uri }} style={{ width: '100%', height: '85%' }} resizeMode="contain" /> : null}
        <Text style={{ color: '#fff', marginTop: 12 }}>Tap anywhere to close</Text>
      </Pressable>
    </Modal>
  );
}

export function Thumb({ uri, size = 44 }) {
  const [open, setOpen] = useState(false);
  if (!uri) return null;
  return (
    <>
      <TouchableOpacity onPress={() => setOpen(true)}>
        <Image source={{ uri }} style={{ width: size, height: size, borderRadius: 8, backgroundColor: colors.border }} />
      </TouchableOpacity>
      <ImageViewer uri={open ? uri : null} onClose={() => setOpen(false)} />
    </>
  );
}

export function ImageField({ att }) {
  const [open, setOpen] = useState(false);
  return (
    <View style={{ marginBottom: 14 }}>
      <Text style={s.label}>Image (optional)</Text>
      {att.image ? (
        <TouchableOpacity onPress={() => setOpen(true)}>
          <Image source={{ uri: att.image }} style={s.preview} resizeMode="cover" />
        </TouchableOpacity>
      ) : null}
      <View style={{ flexDirection: 'row', gap: 10, marginTop: att.image ? 10 : 0 }}>
        <Button
          small
          kind="secondary"
          title="📷 Camera"
          onPress={() => att.pick(true)}
          disabled={att.busy}
          style={{ flex: 1 }}
        />
        <Button
          small
          kind="secondary"
          title="🖼️ Gallery"
          onPress={() => att.pick(false)}
          disabled={att.busy}
          style={{ flex: 1 }}
        />
        {att.image ? (
          <Button small kind="danger" title="Remove" onPress={att.remove} style={{ flex: 1 }} />
        ) : null}
      </View>
      <ImageViewer uri={open ? att.image : null} onClose={() => setOpen(false)} />
    </View>
  );
}

const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.bg },
  header: {
    height: 56,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    backgroundColor: colors.card,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  backBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  backTxt: { fontSize: 34, color: colors.primary, marginTop: -4 },
  title: { flex: 1, fontSize: 19, fontWeight: '700', color: colors.text, paddingHorizontal: 4 },
  right: { minWidth: 8, flexDirection: 'row', alignItems: 'center' },
  card: {
    backgroundColor: colors.card,
    borderRadius: 14,
    padding: 14,
    marginBottom: 12,
    elevation: 1,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 1 },
  },
  btn: { borderRadius: 12, paddingVertical: 14, paddingHorizontal: 16, alignItems: 'center', justifyContent: 'center' },
  btnSmall: { paddingVertical: 10, paddingHorizontal: 10 },
  btnTxt: { fontSize: 16, fontWeight: '700' },
  label: { fontSize: 13, fontWeight: '600', color: colors.muted, marginBottom: 6 },
  input: {
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 16,
    color: colors.text,
  },
  chip: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.card,
    marginRight: 8,
    marginBottom: 8,
  },
  chipTxt: { fontSize: 14, color: colors.text, fontWeight: '600' },
  fab: {
    position: 'absolute',
    right: 16,
    bottom: 16,
    backgroundColor: colors.primary,
    borderRadius: 28,
    paddingHorizontal: 20,
    paddingVertical: 15,
    elevation: 5,
    shadowColor: '#000',
    shadowOpacity: 0.25,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
  },
  fabTxt: { color: '#fff', fontSize: 16, fontWeight: '700' },
  monthRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  monthBtn: { width: 44, height: 40, alignItems: 'center', justifyContent: 'center' },
  monthArrow: { fontSize: 32, color: colors.primary, marginTop: -4 },
  monthTxt: { fontSize: 18, fontWeight: '700', color: colors.text },
  viewer: { flex: 1, backgroundColor: 'rgba(0,0,0,0.95)', alignItems: 'center', justifyContent: 'center' },
  preview: { width: '100%', height: 200, borderRadius: 12, backgroundColor: colors.border },
});

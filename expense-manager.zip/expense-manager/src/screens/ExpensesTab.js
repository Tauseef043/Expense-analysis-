import React, { useMemo, useState } from 'react';
import { Alert, FlatList, Text, TouchableOpacity, View } from 'react-native';
import { useApp } from '../AppContext';
import { getExpensesByMonth, deleteExpense } from '../db';
import { deleteImage } from '../images';
import { CATEGORIES, CAT_BY_KEY, METHOD_BY_KEY } from '../constants';
import { colors } from '../theme';
import { Card, Chip, Empty, Fab, MonthSwitcher, Thumb } from '../ui';
import { monthKey, money, prettyDate, shiftMonth, todayISO, round2 } from '../utils';

export default function ExpensesTab() {
  const { user, nav, version, bump } = useApp();
  const [month, setMonth] = useState(monthKey(todayISO()));
  const [filter, setFilter] = useState('all');

  const rows = useMemo(() => getExpensesByMonth(user.id, month), [user.id, month, version]);

  const total = round2(rows.reduce((a, r) => a + r.amount, 0));
  const cash = round2(rows.filter((r) => r.payment_method === 'cash').reduce((a, r) => a + r.amount, 0));
  const mobile = round2(total - cash);

  const byCat = useMemo(() => {
    const m = {};
    rows.forEach((r) => {
      m[r.category] = round2((m[r.category] || 0) + r.amount);
    });
    return m;
  }, [rows]);

  const shown = filter === 'all' ? rows : rows.filter((r) => r.category === filter);

  const confirmDelete = (r) =>
    Alert.alert('Delete expense', 'Delete this expense of ' + money(r.amount) + '?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          deleteExpense(r.id, user.id);
          await deleteImage(r.image_uri);
          bump();
        },
      },
    ]);

  const header = (
    <View>
      <MonthSwitcher month={month} onChange={(d) => setMonth(shiftMonth(month, d))} />
      <Card style={{ backgroundColor: colors.primary }}>
        <Text style={{ color: '#DBEAFE', fontSize: 13 }}>Total spent this month</Text>
        <Text style={{ color: '#fff', fontSize: 32, fontWeight: '800', marginVertical: 2 }}>{money(total)}</Text>
        <View style={{ flexDirection: 'row', marginTop: 6 }}>
          <Text style={{ color: '#fff', flex: 1 }}>💵 Cash: {money(cash)}</Text>
          <Text style={{ color: '#fff', flex: 1 }}>📱 Mobile: {money(mobile)}</Text>
        </View>
      </Card>

      <Text style={{ fontWeight: '700', color: colors.text, marginBottom: 8, marginTop: 4 }}>By category</Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
        <Chip label="All" selected={filter === 'all'} onPress={() => setFilter('all')} />
        {CATEGORIES.map((c) => (
          <Chip
            key={c.key}
            icon={c.icon}
            label={c.label + (byCat[c.key] ? ' · ' + money(byCat[c.key]) : '')}
            selected={filter === c.key}
            onPress={() => setFilter(filter === c.key ? 'all' : c.key)}
          />
        ))}
      </View>
      <Text style={{ fontWeight: '700', color: colors.text, marginVertical: 8 }}>Transactions</Text>
    </View>
  );

  return (
    <View style={{ flex: 1 }}>
      <FlatList
        data={shown}
        keyExtractor={(r) => String(r.id)}
        ListHeaderComponent={header}
        ListEmptyComponent={<Empty text={'No expenses here yet.\nTap “+ Add expense” to record one.'} />}
        contentContainerStyle={{ padding: 16, paddingBottom: 90 }}
        renderItem={({ item: r }) => {
          const cat = CAT_BY_KEY[r.category] || { icon: '•', label: r.category };
          const method = METHOD_BY_KEY[r.payment_method];
          return (
            <TouchableOpacity
              activeOpacity={0.8}
              onPress={() => nav.push('ExpenseForm', { id: r.id })}
              onLongPress={() => confirmDelete(r)}
            >
              <Card style={{ flexDirection: 'row', alignItems: 'center' }}>
                <Text style={{ fontSize: 26, marginRight: 12 }}>{cat.icon}</Text>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontWeight: '700', color: colors.text }}>{cat.label}</Text>
                  <Text style={{ color: colors.muted, fontSize: 12, marginTop: 2 }}>
                    {prettyDate(r.date)} · {method ? method.icon + ' ' + method.label : r.payment_method}
                  </Text>
                  {r.description ? (
                    <Text style={{ color: colors.text, marginTop: 4 }} numberOfLines={2}>
                      {r.description}
                    </Text>
                  ) : null}
                </View>
                <View style={{ alignItems: 'flex-end' }}>
                  <Text style={{ fontWeight: '800', fontSize: 16, color: colors.danger }}>{money(r.amount)}</Text>
                  {r.image_uri ? (
                    <View style={{ marginTop: 6 }}>
                      <Thumb uri={r.image_uri} size={40} />
                    </View>
                  ) : null}
                </View>
              </Card>
            </TouchableOpacity>
          );
        }}
      />
      <Fab label="+ Add expense" onPress={() => nav.push('ExpenseForm', {})} />
    </View>
  );
}

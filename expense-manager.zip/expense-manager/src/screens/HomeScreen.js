import React, { useState } from 'react';
import { Alert, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useApp } from '../AppContext';
import { colors } from '../theme';
import { Button, Card, Screen } from '../ui';
import ExpensesTab from './ExpensesTab';
import LoansTab from './LoansTab';

const TABS = [
  { key: 'expenses', label: 'Expenses', icon: '🧾' },
  { key: 'loans', label: 'Loans', icon: '🤝' },
  { key: 'account', label: 'Account', icon: '👤' },
];

function AccountTab() {
  const { user, logout } = useApp();
  return (
    <View style={{ padding: 16 }}>
      <Card>
        <Text style={{ color: colors.muted, fontSize: 13 }}>Logged in as</Text>
        <Text style={{ fontSize: 22, fontWeight: '800', color: colors.text, marginTop: 2 }}>{user.username}</Text>
      </Card>
      <Card>
        <Text style={{ color: colors.text, lineHeight: 21 }}>
          Everything you enter is saved in an offline database on this phone. Expenses and loans are tracked
          separately, so they never affect each other's totals.{'\n\n'}
          Uninstalling the app or clearing its data will erase your records.
        </Text>
      </Card>
      <Button
        kind="danger"
        title="Log out"
        onPress={() =>
          Alert.alert('Log out', 'You can log back in with your username and password.', [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Log out', style: 'destructive', onPress: logout },
          ])
        }
      />
    </View>
  );
}

export default function HomeScreen() {
  const [tab, setTab] = useState('expenses');
  const titles = { expenses: 'Daily Expenses', loans: 'Loan Management', account: 'Account' };

  return (
    <Screen title={titles[tab]}>
      <View style={{ flex: 1 }}>
        {/* Tabs stay mounted so month / scroll state is kept when switching */}
        <View style={[styles.fill, tab !== 'expenses' && styles.hidden]}>
          <ExpensesTab />
        </View>
        <View style={[styles.fill, tab !== 'loans' && styles.hidden]}>
          <LoansTab />
        </View>
        <View style={[styles.fill, tab !== 'account' && styles.hidden]}>
          <AccountTab />
        </View>
      </View>
      <View style={styles.tabBar}>
        {TABS.map((t) => {
          const active = t.key === tab;
          return (
            <TouchableOpacity key={t.key} style={styles.tab} onPress={() => setTab(t.key)} activeOpacity={0.7}>
              <Text style={{ fontSize: 20 }}>{t.icon}</Text>
              <Text style={[styles.tabTxt, active && { color: colors.primary }]}>{t.label}</Text>
              {active ? <View style={styles.dot} /> : null}
            </TouchableOpacity>
          );
        })}
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  fill: { ...StyleSheet.absoluteFillObject },
  hidden: { display: 'none' },
  tabBar: {
    flexDirection: 'row',
    backgroundColor: colors.card,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.border,
  },
  tab: { flex: 1, alignItems: 'center', paddingVertical: 8 },
  tabTxt: { fontSize: 12, fontWeight: '700', color: colors.muted, marginTop: 2 },
  dot: { width: 20, height: 3, borderRadius: 2, backgroundColor: colors.primary, marginTop: 4 },
});

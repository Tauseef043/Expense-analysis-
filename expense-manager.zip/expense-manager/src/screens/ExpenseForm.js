import React, { useState } from 'react';
import { Alert, ScrollView, Text, View } from 'react-native';
import { useApp } from '../AppContext';
import { addExpense, getExpense, updateExpense, deleteExpense } from '../db';
import { deleteImage, useAttachment } from '../images';
import { CATEGORIES, PAYMENT_METHODS } from '../constants';
import { colors } from '../theme';
import { Button, Chip, Field, ImageField, Screen } from '../ui';
import { isValidDate, parseAmount, shiftDate, todayISO } from '../utils';

export default function ExpenseForm({ params }) {
  const { user, nav, bump } = useApp();
  const editing = params && params.id ? getExpense(params.id, user.id) : null;

  const [category, setCategory] = useState(editing ? editing.category : CATEGORIES[0].key);
  const [method, setMethod] = useState(editing ? editing.payment_method : 'cash');
  const [amount, setAmount] = useState(editing ? String(editing.amount) : '');
  const [description, setDescription] = useState(editing ? editing.description || '' : '');
  const [date, setDate] = useState(editing ? editing.date : todayISO());
  const att = useAttachment(editing ? editing.image_uri : null);

  const save = async () => {
    const amt = parseAmount(amount);
    if (!(amt > 0)) return Alert.alert('Invalid amount', 'Enter an amount greater than 0.');
    if (!isValidDate(date)) return Alert.alert('Invalid date', 'Use the format YYYY-MM-DD, e.g. 2026-10-29.');
    const data = { category, amount: amt, method, description: description.trim(), imageUri: att.image, date };
    if (editing) updateExpense(editing.id, user.id, data);
    else addExpense(user.id, data);
    await att.commit();
    bump();
    nav.pop();
  };

  const remove = () =>
    Alert.alert('Delete expense', 'This cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          deleteExpense(editing.id, user.id);
          await deleteImage(editing.image_uri);
          await att.commit();
          bump();
          nav.pop();
        },
      },
    ]);

  return (
    <Screen title={editing ? 'Edit expense' : 'Add expense'} onBack={() => nav.pop()}>
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 40 }} keyboardShouldPersistTaps="handled">
        <Text style={lbl}>Category</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginBottom: 6 }}>
          {CATEGORIES.map((c) => (
            <Chip key={c.key} icon={c.icon} label={c.label} selected={category === c.key} onPress={() => setCategory(c.key)} />
          ))}
        </View>

        <Field label="Amount" value={amount} onChangeText={setAmount} keyboardType="decimal-pad" placeholder="0" />

        <Text style={lbl}>Paid with</Text>
        <View style={{ flexDirection: 'row', marginBottom: 14 }}>
          {PAYMENT_METHODS.map((m) => (
            <Chip key={m.key} icon={m.icon} label={m.label} selected={method === m.key} onPress={() => setMethod(m.key)} />
          ))}
        </View>

        <Field label="Date (YYYY-MM-DD)" value={date} onChangeText={setDate} placeholder="2026-10-29" autoCorrect={false} />
        <View style={{ flexDirection: 'row', gap: 8, marginTop: -6, marginBottom: 14 }}>
          <Button small kind="secondary" title="Today" onPress={() => setDate(todayISO())} />
          <Button small kind="secondary" title="Yesterday" onPress={() => setDate(shiftDate(todayISO(), -1))} />
        </View>

        <Field
          label="Description (optional)"
          value={description}
          onChangeText={setDescription}
          multiline
          placeholder="e.g. Petrol 5 litres, oil change, medicine for fever"
        />

        <ImageField att={att} />

        <Button title={editing ? 'Save changes' : 'Save expense'} onPress={save} disabled={att.busy} />
        {editing ? <Button kind="danger" title="Delete" onPress={remove} style={{ marginTop: 10 }} /> : null}
      </ScrollView>
    </Screen>
  );
}

const lbl = { fontSize: 13, fontWeight: '600', color: colors.muted, marginBottom: 6 };

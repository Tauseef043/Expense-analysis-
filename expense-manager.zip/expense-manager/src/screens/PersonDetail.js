import React, { useMemo } from 'react';
import { Alert, FlatList, Text, TouchableOpacity, View } from 'react-native';
import { useApp } from '../AppContext';
import { deletePerson, getPerson, getPersonImages, getTxns, deleteTxn } from '../db';
import { deleteImage, deleteImages } from '../images';
import { TXN_ORDER, TXN_TYPES } from '../constants';
import { colors } from '../theme';
import { Button, Card, Empty, Screen, Thumb } from '../ui';
import { balanceInfo, balanceOf, money, prettyDate, round2 } from '../utils';

export default function PersonDetail({ params }) {
  const { user, nav, version, bump } = useApp();
  const person = useMemo(() => getPerson(params.id, user.id), [params.id, user.id, version]);
  const txns = useMemo(() => getTxns(params.id, user.id), [params.id, user.id, version]);

  if (!person) {
    return (
      <Screen title="Person" onBack={() => nav.pop()}>
        <Empty text="This person no longer exists." />
      </Screen>
    );
  }

  const totals = { given: 0, received: 0, borrowed: 0, paid: 0 };
  txns.forEach((t) => {
    totals[t.type] = round2(totals[t.type] + t.amount);
  });
  const balance = balanceOf(totals);
  const info = balanceInfo(balance, colors);

  const removePerson = () =>
    Alert.alert('Delete person', 'This will also delete all loan entries with ' + person.name + '.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          const imgs = getPersonImages(person.id, user.id);
          deletePerson(person.id, user.id);
          await deleteImages(imgs);
          bump();
          nav.pop();
        },
      },
    ]);

  const removeTxn = (t) =>
    Alert.alert('Delete entry', 'Delete this ' + TXN_TYPES[t.type].short.toLowerCase() + ' entry of ' + money(t.amount) + '?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          deleteTxn(t.id, user.id);
          await deleteImage(t.image_uri);
          bump();
        },
      },
    ]);

  const add = (type) => nav.push('TxnForm', { personId: person.id, type });

  const header = (
    <View>
      <Card>
        <Text style={{ color: colors.muted, fontSize: 13 }}>Net balance</Text>
        <Text style={{ fontSize: 28, fontWeight: '800', color: info.color, marginVertical: 2 }}>{info.text}</Text>
        <View style={{ height: 1, backgroundColor: colors.border, marginVertical: 10 }} />
        <Row label="I gave (loan to them)" value={totals.given} />
        <Row label="They repaid me" value={totals.received} />
        <Row label="I borrowed (loan from them)" value={totals.borrowed} />
        <Row label="I repaid them" value={totals.paid} />
        <Text style={{ color: colors.muted, fontSize: 12, marginTop: 8 }}>
          Balance = (given − repaid to me) − (borrowed − repaid by me)
        </Text>
      </Card>

      <View style={{ flexDirection: 'row', gap: 10, marginBottom: 10 }}>
        <Button small title="➕ I gave loan" onPress={() => add('given')} style={{ flex: 1, backgroundColor: colors.danger }} />
        <Button small title="➕ I took loan" onPress={() => add('borrowed')} style={{ flex: 1, backgroundColor: colors.green }} />
      </View>
      <View style={{ flexDirection: 'row', gap: 10, marginBottom: 14 }}>
        <Button small kind="secondary" title="They repaid me" onPress={() => add('received')} style={{ flex: 1 }} />
        <Button small kind="secondary" title="I repaid them" onPress={() => add('paid')} style={{ flex: 1 }} />
      </View>
      <Text style={{ fontWeight: '700', color: colors.text, marginBottom: 8 }}>History</Text>
    </View>
  );

  const footer = (
    <Button kind="danger" title="Delete this person" onPress={removePerson} style={{ marginTop: 16 }} />
  );

  return (
    <Screen
      title={person.name}
      onBack={() => nav.pop()}
      right={
        <TouchableOpacity onPress={() => nav.push('PersonForm', { id: person.id })} style={{ padding: 10 }}>
          <Text style={{ color: colors.primary, fontWeight: '700' }}>Edit</Text>
        </TouchableOpacity>
      }
    >
      <FlatList
        data={txns}
        keyExtractor={(t) => String(t.id)}
        ListHeaderComponent={header}
        ListFooterComponent={footer}
        ListEmptyComponent={<Empty text="No entries yet. Use the buttons above to add one." />}
        contentContainerStyle={{ padding: 16, paddingBottom: 40 }}
        renderItem={({ item: t }) => {
          const meta = TXN_TYPES[t.type];
          return (
            <TouchableOpacity
              activeOpacity={0.8}
              onPress={() => nav.push('TxnForm', { personId: person.id, id: t.id })}
              onLongPress={() => removeTxn(t)}
            >
              <Card style={{ flexDirection: 'row', alignItems: 'center' }}>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontWeight: '700', color: colors.text }}>{meta.label}</Text>
                  <Text style={{ color: colors.muted, fontSize: 12, marginTop: 2 }}>{prettyDate(t.date)}</Text>
                  {t.description ? (
                    <Text style={{ color: colors.text, marginTop: 4 }} numberOfLines={3}>
                      {t.description}
                    </Text>
                  ) : null}
                </View>
                <View style={{ alignItems: 'flex-end' }}>
                  <Text style={{ fontWeight: '800', fontSize: 16, color: meta.color }}>
                    {meta.sign}
                    {money(t.amount)}
                  </Text>
                  {t.image_uri ? (
                    <View style={{ marginTop: 6 }}>
                      <Thumb uri={t.image_uri} size={40} />
                    </View>
                  ) : null}
                </View>
              </Card>
            </TouchableOpacity>
          );
        }}
      />
    </Screen>
  );
}

function Row({ label, value }) {
  return (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 3 }}>
      <Text style={{ color: colors.text }}>{label}</Text>
      <Text style={{ color: colors.text, fontWeight: '700' }}>{money(value)}</Text>
    </View>
  );
}

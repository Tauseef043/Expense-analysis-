import React, { useMemo } from 'react';
import { FlatList, Text, TouchableOpacity, View } from 'react-native';
import { useApp } from '../AppContext';
import { getPersonsWithTotals } from '../db';
import { colors } from '../theme';
import { Card, Empty, Fab } from '../ui';
import { balanceInfo, balanceOf, money, round2 } from '../utils';

export default function LoansTab() {
  const { user, nav, version } = useApp();

  const persons = useMemo(
    () => getPersonsWithTotals(user.id).map((p) => ({ ...p, balance: balanceOf(p) })),
    [user.id, version]
  );

  const toGet = round2(persons.filter((p) => p.balance > 0).reduce((a, p) => a + p.balance, 0));
  const toPay = round2(persons.filter((p) => p.balance < 0).reduce((a, p) => a - p.balance, 0));

  const header = (
    <View style={{ flexDirection: 'row', gap: 10, marginBottom: 4 }}>
      <Card style={{ flex: 1, backgroundColor: colors.greenSoft }}>
        <Text style={{ color: colors.green, fontWeight: '700', fontSize: 12 }}>YOU WILL GET</Text>
        <Text style={{ color: colors.green, fontWeight: '800', fontSize: 20, marginTop: 4 }}>{money(toGet)}</Text>
      </Card>
      <Card style={{ flex: 1, backgroundColor: colors.dangerSoft }}>
        <Text style={{ color: colors.danger, fontWeight: '700', fontSize: 12 }}>YOU WILL PAY</Text>
        <Text style={{ color: colors.danger, fontWeight: '800', fontSize: 20, marginTop: 4 }}>{money(toPay)}</Text>
      </Card>
    </View>
  );

  return (
    <View style={{ flex: 1 }}>
      <FlatList
        data={persons}
        keyExtractor={(p) => String(p.id)}
        ListHeaderComponent={header}
        ListEmptyComponent={<Empty text={'No people added yet.\nTap “+ Add person” to start tracking loans.'} />}
        contentContainerStyle={{ padding: 16, paddingBottom: 90 }}
        renderItem={({ item: p }) => {
          const info = balanceInfo(p.balance, colors);
          return (
            <TouchableOpacity activeOpacity={0.8} onPress={() => nav.push('PersonDetail', { id: p.id })}>
              <Card style={{ flexDirection: 'row', alignItems: 'center' }}>
                <View
                  style={{
                    width: 44,
                    height: 44,
                    borderRadius: 22,
                    backgroundColor: colors.primarySoft,
                    alignItems: 'center',
                    justifyContent: 'center',
                    marginRight: 12,
                  }}
                >
                  <Text style={{ fontSize: 18, fontWeight: '800', color: colors.primary }}>
                    {p.name.trim().charAt(0).toUpperCase()}
                  </Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontWeight: '700', fontSize: 16, color: colors.text }}>{p.name}</Text>
                  {p.phone ? <Text style={{ color: colors.muted, fontSize: 12 }}>{p.phone}</Text> : null}
                </View>
                <Text style={{ fontWeight: '800', color: info.color }}>{info.text}</Text>
              </Card>
            </TouchableOpacity>
          );
        }}
      />
      <Fab label="+ Add person" onPress={() => nav.push('PersonForm', {})} />
    </View>
  );
}

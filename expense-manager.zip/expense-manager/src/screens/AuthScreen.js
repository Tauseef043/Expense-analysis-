import React, { useState } from 'react';
import { KeyboardAvoidingView, ScrollView, Text, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { signUp, logIn } from '../auth';
import { colors } from '../theme';
import { Button, Field } from '../ui';

export default function AuthScreen({ onAuth }) {
  const insets = useSafeAreaInsets();
  const [mode, setMode] = useState('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const isSignup = mode === 'signup';

  const submit = async () => {
    setError('');
    if (isSignup && password !== confirm) {
      setError('Passwords do not match.');
      return;
    }
    setLoading(true);
    try {
      const user = isSignup ? await signUp(username, password) : await logIn(username, password);
      onAuth(user);
    } catch (e) {
      setError(e.message || 'Something went wrong.');
      setLoading(false);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg, paddingTop: insets.top, paddingBottom: insets.bottom }}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior="padding">
        <ScrollView contentContainerStyle={{ padding: 24, flexGrow: 1, justifyContent: 'center' }} keyboardShouldPersistTaps="handled">
          <Text style={{ fontSize: 44, textAlign: 'center' }}>💰</Text>
          <Text style={{ fontSize: 28, fontWeight: '800', textAlign: 'center', color: colors.text }}>Expense Manager</Text>
          <Text style={{ color: colors.muted, textAlign: 'center', marginBottom: 28, marginTop: 4 }}>
            {isSignup ? 'Create your account' : 'Log in to continue'}
          </Text>

          <Field
            label="Username"
            value={username}
            onChangeText={setUsername}
            autoCapitalize="none"
            autoCorrect={false}
            placeholder="e.g. tousif"
          />
          <Field
            label="Password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            autoCapitalize="none"
            placeholder="At least 4 characters"
          />
          {isSignup ? (
            <Field
              label="Confirm password"
              value={confirm}
              onChangeText={setConfirm}
              secureTextEntry
              autoCapitalize="none"
              placeholder="Repeat password"
            />
          ) : null}

          {error ? <Text style={{ color: colors.danger, marginBottom: 12 }}>{error}</Text> : null}

          <Button title={isSignup ? 'Sign up' : 'Log in'} onPress={submit} loading={loading} />

          <TouchableOpacity
            onPress={() => {
              setMode(isSignup ? 'login' : 'signup');
              setError('');
            }}
            style={{ marginTop: 18, alignItems: 'center' }}
          >
            <Text style={{ color: colors.primary, fontWeight: '600' }}>
              {isSignup ? 'Already have an account? Log in' : "New here? Create an account"}
            </Text>
          </TouchableOpacity>

          <Text style={{ color: colors.muted, textAlign: 'center', marginTop: 28, fontSize: 12 }}>
            Your account and all data are stored only on this phone (offline).
          </Text>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

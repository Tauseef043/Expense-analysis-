import React, { useState } from 'react';
import { Alert, ScrollView, Text, View } from 'react-native';
import { useApp } from '../AppContext';
import { addTxn, deleteTxn, getPerson, getTxn, updateTxn } from '../db';
import { deleteImage, useAttachment } from '../images';
import { TXN_ORDER, TXN_TYPES } from '../constants';
import { colors } from '../theme';
import { Button, Chip, Field, ImageField, Screen } from '../ui';
import { isValidDate, parseAmount, shiftDate, todayISO } from '../utils';

const HINTS = {
  given: 'You lent money to this person. They now owe you more.',
  borrowed: 'You took money from this person. You now owe them more.',
  received: 'This person paid back some of what they owe you.',
  paid: 'You paid back some of what you owe this person.',
};

export default function TxnForm({ params }) {
  const { user, nav, bump } = useApp();
  const editing = params && params.id ? getTxn(params.id, user.id) : null;
  const person = getPerson(editing ? editing.person_id : params.personId, user.id);

  const [type, setType] = useState(editing ? editing.type : params.type || 'given');
  const [amount, setAmount] = useState(editing ? String(editing.amount) : '');
  const [description, setDescription] = useState(editing ? editing.description || '' : '');
  const [date, setDate] = useState(editing ? editing.date : todayISO());
  const att = useAttachment(editing ? editing.image_uri : null);

  if (!person) {
    return (
      <Screen title="Loan entry" onBack={() => nav.pop()}>
        <Text style={{ padding: 16, color: colors.muted }}>This person no longer exists.</Text>
      </Screen>
    );
  }

  const save = async () => {
    const amt = parseAmount(amount);
    if (!(amt > 0)) return Alert.alert('Invalid amount', 'Enter an amount greater than 0.');
    if (!isValidDate(date)) return Alert.alert('Invalid date', 'Use the format YYYY-MM-DD, e.g. 2026-10-29.');
    const data = { personId: person.id, type, amount: amt, description: description.trim(), imageUri: att.image, date };
    if (editing) updateTxn(editing.id, user.id, data);
    else addTxn(user.id, data);
    await att.commit();
    bump();
    nav.pop();
  };

  const remove = () =>
    Alert.alert('Delete entry', 'This cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          deleteTxn(editing.id, user.id);
          await deleteImage(editing.image_uri);
          await att.commit();
          bump();
          nav.pop();
        },
      },
    ]);

  return (
    <Screen title={(editing ? 'Edit entry · ' : 'New entry · ') + person.name} onBack={() => nav.pop()}>
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 40 }} keyboardShouldPersistTaps="handled">
        <Text style={{ fontSize: 13, fontWeight: '600', color: colors.muted, marginBottom: 6 }}>Type</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
          {TXN_ORDER.map((k) => (
            <Chip key={k} label={TXN_TYPES[k].label} selected={type === k} onPress={() => setType(k)} />
          ))}
        </View>
        <Text style={{ color: colors.muted, marginBottom: 14 }}>{HINTS[type]}</Text>

        <Field label="Amount" value={amount} onChangeText={setAmount} keyboardType="decimal-pad" placeholder="0" />
        <Field label="Date (YYYY-MM-DD)" value={date} onChangeText={setDate} placeholder="2026-10-29" autoCorrect={false} />
        <View style={{ flexDirection: 'row', gap: 8, marginTop: -6, marginBottom: 14 }}>
          <Button small kind="secondary" title="Today" onPress={() => setDate(todayISO())} />
          <Button small kind="secondary" title="Yesterday" onPress={() => setDate(shiftDate(todayISO(), -1))} />
        </View>
        <Field
          label="Description (optional)"
          value={description}
          onChangeText={setDescription}
          multiline
          placeholder="e.g. For shop rent, due in December"
        />
        <ImageField att={att} />

        <Button title={editing ? 'Save changes' : 'Save entry'} onPress={save} disabled={att.busy} />
        {editing ? <Button kind="danger" title="Delete" onPress={remove} style={{ marginTop: 10 }} /> : null}
      </ScrollView>
    </Screen>
  );
}

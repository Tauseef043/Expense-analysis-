import * as SQLite from 'expo-sqlite';

let _db = null;

export function db() {
  if (!_db) {
    _db = SQLite.openDatabaseSync('expense_manager.db');
    migrate(_db);
  }
  return _db;
}

function migrate(d) {
  d.execSync(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE,
      salt TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    -- Expense management (completely separate from loans)
    CREATE TABLE IF NOT EXISTS expenses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      category TEXT NOT NULL,
      amount REAL NOT NULL,
      payment_method TEXT NOT NULL,
      description TEXT,
      image_uri TEXT,
      date TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_expenses_user_date ON expenses(user_id, date);

    -- Loan management (completely separate from expenses)
    CREATE TABLE IF NOT EXISTS persons (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      phone TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_persons_user ON persons(user_id);

    CREATE TABLE IF NOT EXISTS loan_txns (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      person_id INTEGER NOT NULL,
      type TEXT NOT NULL,
      amount REAL NOT NULL,
      description TEXT,
      image_uri TEXT,
      date TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (person_id) REFERENCES persons(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_txns_person ON loan_txns(person_id);
  `);
}

const now = () => new Date().toISOString();

/* ------------------------------ users ------------------------------ */

export function findUserByName(username) {
  return db().getFirstSync('SELECT * FROM users WHERE username = ?', [username]);
}

export function findUserById(id) {
  return db().getFirstSync('SELECT * FROM users WHERE id = ?', [id]);
}

export function insertUser(username, salt, hash) {
  const r = db().runSync(
    'INSERT INTO users (username, salt, password_hash, created_at) VALUES (?, ?, ?, ?)',
    [username, salt, hash, now()]
  );
  return r.lastInsertRowId;
}

/* ----------------------------- expenses ---------------------------- */

export function getExpensesByMonth(userId, month) {
  return db().getAllSync(
    'SELECT * FROM expenses WHERE user_id = ? AND substr(date, 1, 7) = ? ORDER BY date DESC, id DESC',
    [userId, month]
  );
}

export function getExpense(id, userId) {
  return db().getFirstSync('SELECT * FROM expenses WHERE id = ? AND user_id = ?', [id, userId]);
}

export function addExpense(userId, e) {
  return db().runSync(
    `INSERT INTO expenses (user_id, category, amount, payment_method, description, image_uri, date, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [userId, e.category, e.amount, e.method, e.description || '', e.imageUri || null, e.date, now()]
  ).lastInsertRowId;
}

export function updateExpense(id, userId, e) {
  db().runSync(
    `UPDATE expenses SET category = ?, amount = ?, payment_method = ?, description = ?, image_uri = ?, date = ?
     WHERE id = ? AND user_id = ?`,
    [e.category, e.amount, e.method, e.description || '', e.imageUri || null, e.date, id, userId]
  );
}

export function deleteExpense(id, userId) {
  db().runSync('DELETE FROM expenses WHERE id = ? AND user_id = ?', [id, userId]);
}

/* ------------------------------ persons ----------------------------- */

export function getPersonsWithTotals(userId) {
  return db().getAllSync(
    `SELECT p.id, p.name, p.phone,
       COALESCE(SUM(CASE WHEN t.type = 'given'    THEN t.amount END), 0) AS given,
       COALESCE(SUM(CASE WHEN t.type = 'received' THEN t.amount END), 0) AS received,
       COALESCE(SUM(CASE WHEN t.type = 'borrowed' THEN t.amount END), 0) AS borrowed,
       COALESCE(SUM(CASE WHEN t.type = 'paid'     THEN t.amount END), 0) AS paid
     FROM persons p
     LEFT JOIN loan_txns t ON t.person_id = p.id
     WHERE p.user_id = ?
     GROUP BY p.id
     ORDER BY p.name COLLATE NOCASE`,
    [userId]
  );
}

export function getPerson(id, userId) {
  return db().getFirstSync('SELECT * FROM persons WHERE id = ? AND user_id = ?', [id, userId]);
}

export function addPerson(userId, p) {
  return db().runSync(
    'INSERT INTO persons (user_id, name, phone, created_at) VALUES (?, ?, ?, ?)',
    [userId, p.name, p.phone || '', now()]
  ).lastInsertRowId;
}

export function updatePerson(id, userId, p) {
  db().runSync('UPDATE persons SET name = ?, phone = ? WHERE id = ? AND user_id = ?', [
    p.name,
    p.phone || '',
    id,
    userId,
  ]);
}

export function getPersonImages(personId, userId) {
  return db()
    .getAllSync(
      'SELECT image_uri FROM loan_txns WHERE person_id = ? AND user_id = ? AND image_uri IS NOT NULL',
      [personId, userId]
    )
    .map((r) => r.image_uri);
}

export function deletePerson(id, userId) {
  // loan_txns rows are removed by ON DELETE CASCADE
  db().runSync('DELETE FROM persons WHERE id = ? AND user_id = ?', [id, userId]);
}

/* ------------------------------ loan txns --------------------------- */

export function getTxns(personId, userId) {
  return db().getAllSync(
    'SELECT * FROM loan_txns WHERE person_id = ? AND user_id = ? ORDER BY date DESC, id DESC',
    [personId, userId]
  );
}

export function getTxn(id, userId) {
  return db().getFirstSync('SELECT * FROM loan_txns WHERE id = ? AND user_id = ?', [id, userId]);
}

export function addTxn(userId, t) {
  return db().runSync(
    `INSERT INTO loan_txns (user_id, person_id, type, amount, description, image_uri, date, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [userId, t.personId, t.type, t.amount, t.description || '', t.imageUri || null, t.date, now()]
  ).lastInsertRowId;
}

export function updateTxn(id, userId, t) {
  db().runSync(
    `UPDATE loan_txns SET type = ?, amount = ?, description = ?, image_uri = ?, date = ?
     WHERE id = ? AND user_id = ?`,
    [t.type, t.amount, t.description || '', t.imageUri || null, t.date, id, userId]
  );
}

export function deleteTxn(id, userId) {
  db().runSync('DELETE FROM loan_txns WHERE id = ? AND user_id = ?', [id, userId]);
}

import { colors } from './theme';

export const CURRENCY = 'Rs';

export const CATEGORIES = [
  { key: 'fuel_bike', label: 'Fuel – Bike', icon: '🏍️' },
  { key: 'fuel_car', label: 'Fuel – Car', icon: '⛽' },
  { key: 'maint_bike', label: 'Maintenance – Bike', icon: '🔧' },
  { key: 'maint_car', label: 'Maintenance – Car', icon: '🛠️' },
  { key: 'food', label: 'Food', icon: '🍔' },
  { key: 'groceries', label: 'Groceries', icon: '🛒' },
  { key: 'shopping', label: 'Shopping', icon: '🛍️' },
  { key: 'utility', label: 'Utility', icon: '💡' },
  { key: 'medicine', label: 'Medicine', icon: '💊' },
];

export const CAT_BY_KEY = CATEGORIES.reduce((acc, c) => {
  acc[c.key] = c;
  return acc;
}, {});

export const PAYMENT_METHODS = [
  { key: 'cash', label: 'Cash', icon: '💵' },
  { key: 'mobile_account', label: 'Mobile Account', icon: '📱' },
];

export const METHOD_BY_KEY = PAYMENT_METHODS.reduce((acc, m) => {
  acc[m.key] = m;
  return acc;
}, {});

// Loan entry types.
//  given    = I gave a loan to the person          (money out)  -> they owe me more
//  received = the person paid me back              (money in)   -> they owe me less
//  borrowed = I took a loan from the person        (money in)   -> I owe them more
//  paid     = I paid the person back               (money out)  -> I owe them less
export const TXN_TYPES = {
  given: { key: 'given', label: 'I gave loan', short: 'Given', sign: '-', color: colors.danger },
  received: { key: 'received', label: 'Got repayment', short: 'Repayment received', sign: '+', color: colors.green },
  borrowed: { key: 'borrowed', label: 'I took loan', short: 'Borrowed', sign: '+', color: colors.green },
  paid: { key: 'paid', label: 'I repaid', short: 'Repaid', sign: '-', color: colors.danger },
};

export const TXN_ORDER = ['given', 'borrowed', 'received', 'paid'];
